
public enum TokenType {

	L_Parens,
	R_Parens,
	Atom;
}
