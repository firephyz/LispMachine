
public enum SymbolType {

	Opcode,
	Symbol,
	Number,
	Boolean;
}
